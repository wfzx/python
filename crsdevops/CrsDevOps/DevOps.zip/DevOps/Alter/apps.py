from django.apps import AppConfig


class AlterConfig(AppConfig):
    name = 'Alter'
