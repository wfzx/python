def IsNullOrSpace(NS):
    if len(NS) == 0:
        return 0
    elif ' ' in NS:
        return 1