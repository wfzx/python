#!/bin/bash
if [ -d "~/python" ];then
	Agent_path="~/python"
else
	mkdir -p ~/python
	Agent_path="~/python"
fi

sudo mv agent.py ${Agent_path}
